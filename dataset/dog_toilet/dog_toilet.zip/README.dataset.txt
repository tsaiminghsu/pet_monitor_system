# dog > 2025-09-25 12:07am
https://universe.roboflow.com/dog-bz4il/dog-jvyyl

Provided by a Roboflow user
License: CC BY 4.0

