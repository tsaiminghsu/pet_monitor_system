from django.urls import path
from stream import views as stream_views
from monitor import views as monitor_views
from monitor import views_api as monitor_api_views


urlpatterns = [
    path("", stream_views.index, name="index"),
    path("video_feed/", stream_views.video_feed, name="video_feed"),
    path("api/stream/video/", stream_views.api_video, name="api_video"),
    path("api/stream/snapshot/", stream_views.snapshot, name="api_snapshot"),
    path("api/stream/stop/", stream_views.stop_stream, name="stop_stream"),
    path("api/realtime/", stream_views.realtime_status, name="realtime_status"),
     # Pets API
    path("api/pets/", monitor_views.api_pets, name="api_pets"),

    # 行為紀錄 API
    path("api/behaviors/", monitor_views.api_behaviors, name="api_behaviors"),
    # 歷史記錄（與 behaviors 相同的資料，提供 /api/history/ 兼容前端請求）
    path("api/history/", monitor_views.api_behaviors, name="api_history"),

    # 即時狀態 API
    path("api/realtime/", monitor_views.api_realtime, name="api_realtime"),
    
    path("api/detections/", monitor_api_views.list_detections, name="detections_list"),
    path("api/detections/post/", monitor_api_views.post_detection, name="detections_post"),
    
]
