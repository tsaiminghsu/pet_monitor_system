# stream/views.py
import os
import sys
import time
from pathlib import Path
import importlib

import cv2
import numpy as np
import torch
from django.http import StreamingHttpResponse, JsonResponse, Http404
from django.shortcuts import render
from django.views.decorators.gzip import gzip_page
from django.views.decorators.http import require_GET
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from monitor.models import PetMonitorBehavior

STREAM_FLAGS = {}

# ---------------- YOLOv7 相容性 Shim ----------------
PROJECT_ROOT = Path(__file__).resolve().parents[1]  # pet_monitor/
YOLO_DIR = PROJECT_ROOT / "yolov7"
if str(YOLO_DIR) not in sys.path:
    sys.path.insert(0, str(YOLO_DIR))

def _ensure_module(alias: str, target: str):
    if alias not in sys.modules:
        sys.modules[alias] = importlib.import_module(target)

_ensure_module("models", "yolov7.models")
_ensure_module("models.common", "yolov7.models.common")
_ensure_module("models.experimental", "yolov7.models.experimental")
_ensure_module("models.yolo", "yolov7.models.yolo")
_ensure_module("utils", "yolov7.utils")
_ensure_module("utils.torch_utils", "yolov7.utils.torch_utils")
_ensure_module("utils.general", "yolov7.utils.general")
_ensure_module("utils.datasets", "yolov7.utils.datasets")
# -----------------------------------------------------

from yolov7.models.experimental import attempt_load
from yolov7.utils.general import non_max_suppression, scale_coords, check_img_size
from yolov7.utils.datasets import letterbox
from yolov7.utils.torch_utils import select_device

# ---------------- 設定 ----------------
DEFAULT_CAMERA_INDEX = 1  # 固定 Camera 1
WEIGHTS = str(PROJECT_ROOT / "weights" / "best.pt")

device = select_device("0" if torch.cuda.is_available() else "cpu")
print(f"使用裝置: {device}")

model = attempt_load(WEIGHTS, map_location=device)
model.eval()
try:
    model.fuse()
except Exception:
    pass
print("✅ YOLOv7 模型載入完成")

CONF_THRES = 0.25
IOU_THRES = 0.45

# ---------------- 工具函式 ----------------
def _open_capture(index: int) -> cv2.VideoCapture:
    """
    嘗試依序用 DirectShow / MSMF 開啟攝影機
    """
    backends = [(cv2.CAP_DSHOW, "DSHOW"), (cv2.CAP_MSMF, "MSMF")]
    for backend, name in backends:
        cap = cv2.VideoCapture(index, backend)
        if cap.isOpened():
            # 設定參數
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
            cap.set(cv2.CAP_PROP_FPS, 30)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            try:
                fourcc = cv2.VideoWriter_fourcc(*"MJPG")
                cap.set(cv2.CAP_PROP_FOURCC, fourcc)
            except Exception:
                pass
            # 丟幾張暖機幀
            for _ in range(5):
                cap.read()
            print(f"[Camera] Opened index={index} via {name}")
            return cap
        cap.release()
    raise Http404(f"無法開啟攝影機 index={index}")

def save_detection(behavior: str, confidence: float, health_status: str = "normal"):
    try:
        PetMonitorBehavior.objects.create(
            behavior=behavior,
            confidence=float(confidence),
            health_status=health_status,
        )
    except Exception as e:
        print(f"[WARN] save_detection failed: {e}")

# ---------------- 推論 ----------------
def gen_frames(
    source=DEFAULT_CAMERA_INDEX,
    img_size=640,
    conf_thres=0.25,
    iou_thres=0.45,
    health_status_default="normal",
):
    stride = 32
    img_size = check_img_size(img_size, s=stride)

    cam_index = int(source) if str(source).isdigit() else source
    STREAM_FLAGS[str(cam_index)] = True

    cap = _open_capture(cam_index)

    fail_count, MAX_FAIL = 0, 30
    try:
        while True:
            # 停止旗標
            if not STREAM_FLAGS.get(str(cam_index), True):
                print(f"[Stream] source={cam_index} 收到停止指令，結束串流")
                break

            ok, frame = cap.read()
            if not ok or frame is None:
                fail_count += 1
                if fail_count >= MAX_FAIL:
                    print(f"[Camera {cam_index}] 讀取失敗 {MAX_FAIL} 次，結束串流")
                    # 產生一張錯誤圖直接送出
                    error_img = np.zeros((480, 640, 3), dtype=np.uint8)
                    error_img[:] = (0, 0, 255)
                    cv2.putText(error_img, "Camera Error",
                                (50, 240), cv2.FONT_HERSHEY_SIMPLEX,
                                2, (255, 255, 255), 3)
                    ok2, buffer2 = cv2.imencode(".jpg", error_img)
                    if ok2:
                        yield (b"--frame\r\n"
                               b"Content-Type: image/jpeg\r\n\r\n" + buffer2.tobytes() + b"\r\n")
                    break
                # 小睡一下再試
                import time as _time
                _time.sleep(0.1)
                continue
            else:
                fail_count = 0

            # 預設拿原始畫面做為待輸出的底圖，確保一定有圖可編碼
            img0 = frame.copy()

            try:
                # --- 前處理 ---
                lb = letterbox(img0, img_size, stride=stride, auto=True)[0]
                img = lb[:, :, ::-1].transpose(2, 0, 1)  # BGR->RGB, HWC->CHW
                img = np.ascontiguousarray(img)
                img = torch.from_numpy(img).to(device).float() / 255.0
                if img.ndimension() == 3:
                    img = img.unsqueeze(0)

                # --- 推論 ---
                with torch.no_grad():
                    pred = model(img)[0]

                # --- NMS ---
                pred = non_max_suppression(pred, conf_thres, iou_thres)[0]

                # --- 畫框/寫DB ---
                if pred is not None and len(pred):
                    pred[:, :4] = scale_coords(img.shape[2:], pred[:, :4], img0.shape).round()
                    for *xyxy, conf, cls in pred:
                        x1, y1, x2, y2 = map(int, xyxy)
                        label_idx = int(cls)
                        # 有 names 就用，沒有就用索引字串
                        label = (model.names[label_idx] if hasattr(model, "names") and label_idx in model.names
                                 else str(label_idx))
                        confidence = float(conf)

                        # 寫 DB（忽略失敗）
                        try:
                            save_detection(label, confidence, health_status_default)
                        except Exception as e:
                            print(f"[save_detection] DB error: {e}")

                        cv2.rectangle(img0, (x1, y1), (x2, y2), (0, 255, 0), 2)
                        cv2.putText(img0, f"{label} {confidence:.2f}",
                                    (x1, max(0, y1 - 5)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                                    (0, 255, 0), 2)
            except Exception as e:
                # 推論/前處理出了問題就覆蓋一條錯誤訊息，但仍送出目前 img0
                cv2.putText(img0, f"Inference error: {e}",
                            (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                            0.8, (0, 0, 255), 2)

            # --- 編碼送出（一定有 img0）---
            ok_enc, buffer = cv2.imencode(".jpg", img0)
            if not ok_enc:
                # 若編碼失敗，送一張全黑替代，避免 NameError
                fallback = np.zeros_like(img0)
                ok_fb, buf_fb = cv2.imencode(".jpg", fallback)
                if ok_fb:
                    yield (b"--frame\r\n"
                           b"Content-Type: image/jpeg\r\n\r\n" + buf_fb.tobytes() + b"\r\n")
                continue

            yield (b"--frame\r\n"
                   b"Content-Type: image/jpeg\r\n\r\n" + buffer.tobytes() + b"\r\n")

    finally:
        cap.release()
        STREAM_FLAGS.pop(str(cam_index), None)
        print(f"[Camera {cam_index}] 已釋放資源，串流結束")


# ---------------- Django Views ----------------
def index(request):
    return render(request, "index.html")

@gzip_page
def video_feed(request, cam_id: int = DEFAULT_CAMERA_INDEX):
    cap = _open_capture(cam_id)
    return StreamingHttpResponse(gen_frames(source=cam_id),
                                 content_type="multipart/x-mixed-replace; boundary=frame")

@require_GET
def api_video(request):
    source = request.GET.get("source", str(DEFAULT_CAMERA_INDEX))
    return StreamingHttpResponse(gen_frames(source=source),
                                 content_type="multipart/x-mixed-replace; boundary=frame")

@require_GET
def snapshot(request):
    cam_id = int(request.GET.get("source", DEFAULT_CAMERA_INDEX))
    cap = _open_capture(cam_id)
    ok, frame = cap.read()
    cap.release()
    if not ok:
        raise Http404(f"無法讀取攝影機畫面 index={cam_id}")
    frame = frame.copy()
    ok, buffer = cv2.imencode(".jpg", frame)
    if not ok:
        raise Http404("影像編碼失敗")
    return StreamingHttpResponse(buffer.tobytes(), content_type="image/jpeg")

@require_GET
def check_device(request):
    return JsonResponse({
        "torch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "device": str(device)
    })

@require_GET
def pets_api(request):
    records = (PetMonitorBehavior.objects.all()
               .order_by("-timestamp")[:10]
               .values("id", "behavior", "confidence", "health_status", "timestamp"))
    return JsonResponse(list(records), safe=False)

@require_GET
def realtime_status(request):
    return JsonResponse({"status": "ok"})

@csrf_exempt
@require_http_methods(["GET", "POST"])
def stop_stream(request):
    """停止指定串流: /api/stream/stop/?source=1 或 POST source=1"""
    source = request.GET.get("source") or request.POST.get("source") or "1"
    STREAM_FLAGS[source] = False
    return JsonResponse({"status": "stopped", "source": source})