from django.db import models

class Pet(models.Model):
    name = models.CharField(max_length=50)

class Behavior(models.Model):
    pet = models.ForeignKey(Pet, on_delete=models.CASCADE)
    behavior = models.CharField(max_length=20)  # eating, toilet, lying
    confidence = models.FloatField()
    timestamp = models.DateTimeField(auto_now_add=True)
    duration = models.IntegerField(default=0)  # 秒
    
class PetMonitorBehavior(models.Model):
    behavior = models.CharField(max_length=100)
    confidence = models.FloatField(default=0.0)
    health_status = models.CharField(max_length=20, default="normal")
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "pet_monitor_behavior"  # 可對應你想要的表名
        
